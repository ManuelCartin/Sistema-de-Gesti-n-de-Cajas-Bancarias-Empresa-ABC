/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.proyectoestructuraempresaabc.Estructura;

/**
 *
 * @author user
 */

public class GrafoProductos {

    private NodoProducto primerProducto;

    public GrafoProductos() {
        this.primerProducto = null;
        inicializarGrafoPredeterminado();
    }

 // Inserta un nuevo vértice al grafo

    public void agregarProducto(String nombre) {
        if (buscarProducto(nombre) == null) {
            NodoProducto nuevo = new NodoProducto(nombre);
            if (primerProducto == null) {
                primerProducto = nuevo;
            } else {
                NodoProducto actual = primerProducto;
                while (actual.getSiguiente() != null) {
                    actual = actual.getSiguiente();
                }
                actual.setSiguiente(nuevo);
            }
        }
    }

// Agrega una relación

    public void agregarRelacion(String origen, String destino) {
        agregarProducto(origen);
        agregarProducto(destino);

        NodoProducto pOrigen = buscarProducto(origen);
        NodoProducto pDestino = buscarProducto(destino);

        if (pOrigen != null && pDestino != null) {
            // Verificar si la relación ya existe para evitar duplicados
            NodoArista actualArista = pOrigen.getPrimerArista();
            while (actualArista != null) {
                if (actualArista.getDestino().getNombre().equalsIgnoreCase(destino)) {
                    return; // Ya existe la conexión
                }
                actualArista = actualArista.getSiguiente();
            }

            // Insertar la nueva arista al final de la lista de adyacencia
            NodoArista nuevaArista = new NodoArista(pDestino);
            if (pOrigen.getPrimerArista() == null) {
                pOrigen.setPrimerArista(nuevaArista);
            } else {
                actualArista = pOrigen.getPrimerArista();
                while (actualArista.getSiguiente() != null) {
                    actualArista = actualArista.getSiguiente();
                }
                actualArista.setSiguiente(nuevaArista);
            }
        }
    }


     // Busca un vértice
    private NodoProducto buscarProducto(String nombre) {
        NodoProducto actual = primerProducto;
        while (actual != null) {
            if (actual.getNombre().equalsIgnoreCase(nombre.trim())) {
                return actual;
            }
            actual = actual.getSiguiente();
        }
        return null;
    }

     // Retorna un resumen
    public String obtenerRecomendaciones(String nombreTramite) {
        NodoProducto producto = buscarProducto(nombreTramite);
        if (producto == null || producto.getPrimerArista() == null) {
            return "No hay productos complementarios registrados para este trámite.";
        }

        StringBuilder recomendaciones = new StringBuilder();
        recomendaciones.append("=== PRODUCTOS SUGERIDOS PARA VENTA CRUZADA ===\n\n");

        NodoArista aristaActual = producto.getPrimerArista();
        int contador = 1;

        while (aristaActual != null) {
            recomendaciones.append(contador)
                           .append(". ")
                           .append(aristaActual.getDestino().getNombre())
                           .append("\n");
            contador++;
            aristaActual = aristaActual.getSiguiente();
        }

        return recomendaciones.toString();
    }

    private void inicializarGrafoPredeterminado() {
        // Trámite: Depósitos
        agregarRelacion("Depósitos", "Apertura de Cuenta a Plazo Fijo");
        agregarRelacion("Depósitos", "Plan de Ahorro Programado");
        agregarRelacion("Depósitos", "Tarjeta de Débito Gold");

        // Trámite: Retiros
        agregarRelacion("Retiros", "Seguro de Protección de Efectivo / Cajero");
        agregarRelacion("Retiros", "Aumento de Límite Diario de Retiro");

        // Trámite: Cambio de Divisas
        agregarRelacion("Cambio de Divisas", "Seguro de Viaje Internacional");
        agregarRelacion("Cambio de Divisas", "Tarjeta Multidivisa Flex");
        agregarRelacion("Cambio de Divisas", "Transferencia Internacional SWIFT");
    }
}