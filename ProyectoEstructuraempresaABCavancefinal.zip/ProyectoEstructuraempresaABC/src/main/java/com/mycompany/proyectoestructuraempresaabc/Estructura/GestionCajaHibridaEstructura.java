/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.proyectoestructuraempresaabc.Estructura;

/**
 * @author user
 */
public class GestionCajaHibridaEstructura {

    // SUBCLASE INTERNA: NODO HÍBRIDO
    public static class NodoCaja {
        private Caja dato;
        
        // Punteros de Lista Doblemente Enlazada Circular (Ordenada por carga de clientes)
        private NodoCaja sig;
        private NodoCaja ant;
        
        // Punteros de Árbol Binario de Búsqueda (Ordenado por número identificador de Caja)
        private NodoCaja izq;
        private NodoCaja der;

        public NodoCaja(Caja dato) {
            this.dato = dato;
        }

        public Caja getDato() { return dato; }
        public NodoCaja getSig() { return sig; }
        public void setSig(NodoCaja sig) { this.sig = sig; }
        public NodoCaja getAnt() { return ant; }
        public void setAnt(NodoCaja ant) { this.ant = ant; }
        public NodoCaja getIzq() { return izq; }
        public void setIzq(NodoCaja izq) { this.izq = izq; }
        public NodoCaja getDer() { return der; }
        public void setDer(NodoCaja der) { this.der = der; }
    }

    // SUBCLASE INTERNA: NODO PARA EL ÁRBOL DE DECISIÓN
    private static class NodoArbolDecision {
        private String preguntaOClasificacion;
        private NodoArbolDecision izq;
        private NodoArbolDecision der;

        public NodoArbolDecision(String texto) {
            this.preguntaOClasificacion = texto;
        }
        public String getPreguntaOClasificacion() { return preguntaOClasificacion; }
        public NodoArbolDecision getIzq() { return izq; }
        public void setIzq(NodoArbolDecision izq) { this.izq = izq; }
        public NodoArbolDecision getDer() { return der; }
        public void setDer(NodoArbolDecision der) { this.der = der; }
    }

    // ATRIBUTOS DE LA CLASE PRINCIPAL HÍBRIDA
    private NodoCaja ini, fin;          // Punteros de la Lista Circular
    private NodoCaja raizCajas;         // Raíz del Árbol de Cajas (búsqueda rápida)
    private NodoArbolDecision raizArbol;// Raíz del Árbol de Decisiones (clasificación)

    // CONSTRUCTOR
    public GestionCajaHibridaEstructura() {
        this.raizArbol = new NodoArbolDecision("¿Es cliente Preferencial?");
        
        this.raizArbol.setDer(new NodoArbolDecision("PREFERENCIAL")); 
        this.raizArbol.setIzq(new NodoArbolDecision("¿Tiene 2 o más trámites?")); 
        
        NodoArbolDecision subPregunta = this.raizArbol.getIzq();
        subPregunta.setDer(new NodoArbolDecision("COMUN")); 
        subPregunta.setIzq(new NodoArbolDecision("¿Es tiquete de Caja Rápida?")); 
        
        NodoArbolDecision ultimaPregunta = subPregunta.getIzq();
        ultimaPregunta.setDer(new NodoArbolDecision("RAPIDA"));
        ultimaPregunta.setIzq(new NodoArbolDecision("COMUN"));
    }

    public boolean esVacia() {
        return ini == null;
    }

    public NodoCaja getRaizCajas() {
        return raizCajas;
    }

    public NodoCaja getIni() {
        return ini;
    }

    // MÉTODOS DE LA LISTA ENLAZADA CIRCULAR
    public void insertarEnLista(NodoCaja nuevo) {
        // Limpiamos punteros de lista por seguridad
        nuevo.setSig(null);
        nuevo.setAnt(null);

        Caja c = nuevo.getDato();
        if (esVacia()) {
            ini = fin = nuevo;
            fin.setSig(ini);
            ini.setAnt(fin);
        } else if (c.getCantidadClientes() <= ini.getDato().getCantidadClientes()) {
            nuevo.setSig(ini);
            ini.setAnt(nuevo);
            ini = nuevo;
            fin.setSig(ini);
            ini.setAnt(fin);
        } else if (c.getCantidadClientes() >= fin.getDato().getCantidadClientes()) {
            fin.setSig(nuevo);
            nuevo.setAnt(fin); 
            fin = nuevo;
            fin.setSig(ini);
            ini.setAnt(fin);
        } else {
            NodoCaja aux = ini;
            while (aux.getSig().getDato().getCantidadClientes() < c.getCantidadClientes()) {
                aux = aux.getSig();
            }
            nuevo.setSig(aux.getSig());
            nuevo.getSig().setAnt(nuevo); 
            aux.setSig(nuevo);
            nuevo.setAnt(aux);
        }
    }

    public NodoCaja extraerNodoDeLista(int numeroCaja) {
        if (esVacia()) return null;
        
        NodoCaja aux = ini;
        do {
            if (aux.getDato().getNumeroCaja() == numeroCaja) {
                if (ini == fin && ini.getDato().getNumeroCaja() == numeroCaja) {
                    ini = fin = null;
                } else {
                    if (aux == ini) {
                        ini = ini.getSig();
                        fin.setSig(ini);
                        ini.setAnt(fin);
                    } else if (aux == fin) {
                        fin = fin.getAnt();
                        fin.setSig(ini);
                        ini.setAnt(fin);
                    } else {
                        aux.getAnt().setSig(aux.getSig());
                        aux.getSig().setAnt(aux.getAnt());
                    }
                }
                aux.setSig(null);
                aux.setAnt(null);
                return aux;
            }
            aux = aux.getSig();
        } while (aux != ini);
        return null;
    }

    public Caja extraerCajaDeLista(int numeroCaja) {
        NodoCaja extraido = extraerNodoDeLista(numeroCaja);
        return (extraido != null) ? extraido.getDato() : null;
    }

    // Recalibra la posición del nodo en la Lista Circular cuando su carga cambia
    public void reordenarCajaEnLista(int numeroCaja) {
        NodoCaja nodo = extraerNodoDeLista(numeroCaja);
        if (nodo != null) {
            insertarEnLista(nodo);
        }
    }

    // MÉTODOS DEL ÁRBOL BINARIO DE BÚSQUEDA
    public void registrarNuevaCaja(Caja c) {
        NodoCaja nuevo = new NodoCaja(c);
        insertarEnLista(nuevo); // Punteros horizontales
        raizCajas = insertarEnArbol(raizCajas, nuevo); // Punteros verticales
    }

    private NodoCaja insertarEnArbol(NodoCaja raizActual, NodoCaja nuevo) {
        if (raizActual == null) return nuevo;
        
        if (nuevo.getDato().getNumeroCaja() < raizActual.getDato().getNumeroCaja()) {
            raizActual.setIzq(insertarEnArbol(raizActual.getIzq(), nuevo));
        } else if (nuevo.getDato().getNumeroCaja() > raizActual.getDato().getNumeroCaja()) {
            raizActual.setDer(insertarEnArbol(raizActual.getDer(), nuevo));
        }
        return raizActual;
    }

    public NodoCaja buscarNodoCajaPorID(NodoCaja raizActual, int numeroCaja) {
        if (raizActual == null || raizActual.getDato().getNumeroCaja() == numeroCaja) {
            return raizActual;
        }
        if (numeroCaja < raizActual.getDato().getNumeroCaja()) {
            return buscarNodoCajaPorID(raizActual.getIzq(), numeroCaja);
        }
        return buscarNodoCajaPorID(raizActual.getDer(), numeroCaja);
    }

    // MÉTODOS DEL ÁRBOL DE DECISIÓN
    public String clasificarCliente(char tipoCliente, int cantidadTramites) {
        NodoArbolDecision aux = raizArbol;

        while (aux.getIzq() != null && aux.getDer() != null) { 
            if (aux.getPreguntaOClasificacion().equals("¿Es cliente Preferencial?")) {
                aux = (tipoCliente == 'P') ? aux.getDer() : aux.getIzq();
            } 
            else if (aux.getPreguntaOClasificacion().equals("¿Tiene 2 o más trámites?")) {
                aux = (cantidadTramites >= 2) ? aux.getDer() : aux.getIzq();
            } 
            else if (aux.getPreguntaOClasificacion().equals("¿Es tiquete de Caja Rápida?")) {
                aux = (tipoCliente == 'A') ? aux.getDer() : aux.getIzq();
            }
        }
        return aux.getPreguntaOClasificacion(); 
    }

    // FLUJO DE ASIGNACIÓN DE CLIENTES
    public void recibirYAsignarCliente(String nombre, String id, int edad, String tramite, char tipo, int cantidadTramites) {
        if (esVacia()) {
            System.out.println("No existen cajas operando en el sistema.");
            return;
        }

        String tipoCajaDestino = clasificarCliente(tipo, cantidadTramites);

        NodoCaja aux = ini;
        NodoCaja mejorCaja = null;

        // La lista circular está ordenada por menor carga de clientes (ini = la más desocupada)
        do {
            if (aux.getDato().getTipoCaja().equals(tipoCajaDestino)) {
                mejorCaja = aux; 
                break; // Tomamos la primera que coincida porque es la más vacía
            }
            aux = aux.getSig();
        } while (aux != ini);

        if (mejorCaja != null) {
            Caja cajaTarget = mejorCaja.getDato();
            
            // Desconectamos el nodo solo de la lista circular
            extraerNodoDeLista(cajaTarget.getNumeroCaja());
            
            // Insertamos el tiquete en la cola
            int personasAdelante = cajaTarget.getColaClientes().insertarTiquete(nombre, id, edad, tramite, tipo);
            
            // Reinsertamos el nodo en la lista en su posición según su nueva carga
            insertarEnLista(mejorCaja);
            
            System.out.println("Cliente " + nombre + " asignado a la Caja " + cajaTarget.getNumeroCaja() + 
                               " [" + tipoCajaDestino + "]. Clientes en fila: " + cajaTarget.getCantidadClientes() +
                               ". Personas adelante: " + personasAdelante);
        } else {
            System.out.println("Error: No se encontró ninguna caja activa del tipo " + tipoCajaDestino);
        }
    }
}