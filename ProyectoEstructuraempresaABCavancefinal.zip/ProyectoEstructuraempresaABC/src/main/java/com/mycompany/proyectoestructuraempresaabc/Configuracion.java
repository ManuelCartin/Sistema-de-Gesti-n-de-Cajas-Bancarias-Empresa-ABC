/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.proyectoestructuraempresaabc;

import java.io.*;
import javax.swing.JOptionPane;

/**
 * @author user
 */
public class Configuracion {

    private static final String ARCHIVO = "prod.txt";
    private String nombreBanco;
    private int cantidadCajas;

    public boolean cargarConfiguracion() {
        File file = new File(ARCHIVO);
        if (!file.exists()) return false;
        
        try (BufferedReader br = new BufferedReader(new FileReader(file))) {
            this.nombreBanco = br.readLine();
            int cajasLeidas = Integer.parseInt(br.readLine());

            // SEGURIDAD: Si el archivo tenía menos de 4 cajas, forzamos mínimo 4
            if (cajasLeidas < 4) {
                this.cantidadCajas = 4;
                guardarConfiguracion(this.nombreBanco, 4); // Actualizamos el archivo
            } else {
                this.cantidadCajas = cajasLeidas;
            }

            return true;
        } catch (Exception e) {
            return false;
        }
    }

    public void guardarConfiguracion(String banco, int cajas) {
        // Aseguramos que nunca se guarde un valor menor a 4
        if (cajas < 4) {
            cajas = 4;
        }

        try (BufferedWriter bw = new BufferedWriter(new FileWriter(ARCHIVO))) {
            bw.write(banco);
            bw.newLine();
            bw.write(String.valueOf(cajas));
            this.nombreBanco = banco;
            this.cantidadCajas = cajas;
            
            // Opcional: Notificación al usuario si no fue actualización automática
            // JOptionPane.showMessageDialog(null, "Configuración registrada en " + ARCHIVO, "Éxito", JOptionPane.INFORMATION_MESSAGE);
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error al escribir " + ARCHIVO + ": " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    // GETTERS Y SETTERS COMPROBADOS
    public String getNombreBanco() { 
        return nombreBanco; 
    }

    public void setNombreBanco(String nombreBanco) {
        this.nombreBanco = nombreBanco;
    }

    public int getCantidadCajas() { 
        return cantidadCajas; 
    }

    public void setCantidadCajas(int cantidadCajas) {
        this.cantidadCajas = (cantidadCajas < 4) ? 4 : cantidadCajas;
    }
}