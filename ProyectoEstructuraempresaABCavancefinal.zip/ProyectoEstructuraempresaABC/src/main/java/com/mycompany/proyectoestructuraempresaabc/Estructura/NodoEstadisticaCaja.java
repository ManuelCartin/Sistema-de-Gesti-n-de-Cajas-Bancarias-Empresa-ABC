/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.proyectoestructuraempresaabc.Estructura;


/**
 *
 * @author user
 */

public class NodoEstadisticaCaja {
    private int numCaja;
    private int totalClientesAtendidos;
    private long tiempoTotalEspera;
    private NodoEstadisticaCaja siguiente;

    public NodoEstadisticaCaja(int numCaja, long tiempoInicial) {
        this.numCaja = numCaja;
        this.totalClientesAtendidos = 1;
        this.tiempoTotalEspera = tiempoInicial;
        this.siguiente = null;
    }

    public void acumularAtencion(long tiempo) {
        this.totalClientesAtendidos++;
        this.tiempoTotalEspera += tiempo;
    }

    // Getters y Setters
    public int getNumCaja() { return numCaja; }
    public int getTotalClientesAtendidos() { return totalClientesAtendidos; }
    public long getTiempoTotalEspera() { return tiempoTotalEspera; }
    public NodoEstadisticaCaja getSiguiente() { return siguiente; }
    public void setSiguiente(NodoEstadisticaCaja siguiente) { this.siguiente = siguiente; }

    public double getPromedioTiempo() {
        return totalClientesAtendidos > 0 ? (double) tiempoTotalEspera / totalClientesAtendidos : 0.0;
    }
}

class ListaEstadisticasCaja {
    private NodoEstadisticaCaja cabeza;

    public void acumularAtencion(int numCaja, long tiempo) {
        NodoEstadisticaCaja aux = cabeza;
        while (aux != null) {
            if (aux.getNumCaja() == numCaja) {
                aux.acumularAtencion(tiempo);
                return;
            }
            aux = aux.getSiguiente();
        }

        // Inserción al inicio usando el setter
        NodoEstadisticaCaja nuevo = new NodoEstadisticaCaja(numCaja, tiempo);
        nuevo.setSiguiente(cabeza);
        cabeza = nuevo;
    }

    public NodoEstadisticaCaja getCabeza() {
        return cabeza;
    }
}