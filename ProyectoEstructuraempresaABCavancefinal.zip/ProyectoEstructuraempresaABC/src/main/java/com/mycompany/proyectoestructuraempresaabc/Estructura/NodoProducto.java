/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.proyectoestructuraempresaabc.Estructura;

/**
 *
 * @author user
 */

public class NodoProducto {
    private String nombre;
    private NodoArista primerArista;
    private NodoProducto siguiente;

    public NodoProducto(String nombre) {
        this.nombre = nombre;
        this.primerArista = null;
        this.siguiente = null;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public NodoArista getPrimerArista() {
        return primerArista;
    }

    public void setPrimerArista(NodoArista primerArista) {
        this.primerArista = primerArista;
    }

    public NodoProducto getSiguiente() {
        return siguiente;
    }

    public void setSiguiente(NodoProducto siguiente) {
        this.siguiente = siguiente;
    }
}