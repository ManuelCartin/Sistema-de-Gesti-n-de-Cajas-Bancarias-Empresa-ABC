/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.proyectoestructuraempresaabc.Estructura;
/**
 *
 * @author user
 */
public class Caja {
    private int numeroCaja;
    private String tipoCaja; // "PREFERENCIAL", "RAPIDA", "COMUN"
    private ColaPrioridad colaClientes;

    public Caja(int numeroCaja, String tipoCaja) {
        this.numeroCaja = numeroCaja;
        this.tipoCaja = tipoCaja;
        this.colaClientes = new ColaPrioridad();
    }

    public int getNumeroCaja() { return numeroCaja; }
    public String getTipoCaja() { return tipoCaja; }
    public ColaPrioridad getColaClientes() { return colaClientes; }
    
    // Método que usará la lista para ordenar
    public int getCantidadClientes() {
        return colaClientes.getTamanoActual();
    }
}