/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.proyectoestructuraempresaabc.Estructura;

/**
 *
 * @author user
 */
public class ColaPrioridad {
    private NodoCliente inicio;
    private int contadorTiquetes;
    private int tamanoReal; // NUEVA VARIABLE: Para saber cuánta gente hay en el momento

    public ColaPrioridad() {
        this.inicio = null;
        this.contadorTiquetes = 0;
        this.tamanoReal = 0; // Inicia en 0
    }

    public int getContadorTiquetes() {
        return contadorTiquetes;
    }

    // MÉTODO: llamar la clase Caja
    public int getTamanoActual() {
        return tamanoReal;
    }

    // Módulo 1.1
    public int insertarTiquete(String nombre, String id, int edad, String tramite, char tipo) {
        contadorTiquetes++;
        tamanoReal++; // INCREMENTA AQUÍ: Entró un cliente a la fila
        
        NodoCliente nuevo = new NodoCliente(nombre, id, edad, tramite, tipo, contadorTiquetes);
        int personasAdelante = 0;

        // Caso 1: La cola vacía
        if (inicio == null) {
            inicio = nuevo;
            return 0; 
        } 
        // Caso 2: nuevo tiquete tiene mayor prioridad que el inicio actual
        else if (evaluarPrioridad(nuevo.getTipo()) > evaluarPrioridad(inicio.getTipo())) {
            nuevo.setSiguiente(inicio);
            inicio = nuevo;
            return 0; 
        } 
        // Caso 3: Buscar la posición correcta según la prioridad
        else {
            NodoCliente actual = inicio;
            personasAdelante = 1;
            
            // Recorremos mientras el siguiente no sea nulo y tenga mayor o igual prioridad
            while (actual.getSiguiente() != null && 
                   evaluarPrioridad(actual.getSiguiente().getTipo()) >= evaluarPrioridad(nuevo.getTipo())) {
                actual = actual.getSiguiente();
                personasAdelante++;
            }
            
            // Insertamos el nodo en medio o al final
            nuevo.setSiguiente(actual.getSiguiente());
            actual.setSiguiente(nuevo);
            
            return personasAdelante;
        }
    }

    private int evaluarPrioridad(char tipo) {
        switch (tipo) {
            case 'P': return 3; // Máxima prioridad
            case 'A': return 2;
            case 'B': return 1; // Menor prioridad
            default: return 0;
        }
    }

    public int contarPersonasAdelante(char tipo, int numTiqueteActual) {
        int personas = 0;
        NodoCliente actual = inicio;
        while (actual != null && actual.getNumeroTiquete() != numTiqueteActual) {
            if (actual.getTipo() == tipo) {
                personas++;
            }
            actual = actual.getSiguiente();
        }
        return personas;
    }

    public boolean estaVacia() {
        return inicio == null;
    }
    
    public NodoCliente desencolar() {
        if (estaVacia()) {
            return null;
        }
        tamanoReal--; // DECREMENTA AQUÍ: Alguien salió de la fila porque ya lo atendieron
        
        NodoCliente auxiliat = inicio;
        inicio = inicio.getSiguiente(); // El segundo pasa a ser el primero
        auxiliat.setSiguiente(null);    // Desenganchamos el nodo extraído
        return auxiliat;
    }
}