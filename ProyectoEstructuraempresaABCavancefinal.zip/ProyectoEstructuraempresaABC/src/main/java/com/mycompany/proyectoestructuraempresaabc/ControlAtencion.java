/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.proyectoestructuraempresaabc;

import com.mycompany.proyectoestructuraempresaabc.Estructura.GestionCajaHibridaEstructura;
import com.mycompany.proyectoestructuraempresaabc.Estructura.Caja;
import com.mycompany.proyectoestructuraempresaabc.Estructura.GrafoProductos;
import com.mycompany.proyectoestructuraempresaabc.Estructura.NodoCliente;
import com.mycompany.proyectoestructuraempresaabc.Estructura.ServicioBCCR;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.swing.JOptionPane;

/**
 * @author user
 */

public class ControlAtencion {

    private GestionCajaHibridaEstructura sistemaCajas;
    private Caja cajaPreferencial;
    private Caja cajaRapida;
    private GrafoProductos grafoProductos; // Grafo de Venta Cruzada
    private ServicioBCCR servicioBCCR;     // ATRIBUTO DEL SERVICIO BCCR

    public ControlAtencion(GestionCajaHibridaEstructura sistemaCajas, Caja preferencial, Caja rapida) {
        this.sistemaCajas = sistemaCajas;
        this.cajaPreferencial = preferencial;
        this.cajaRapida = rapida;
        this.grafoProductos = new GrafoProductos();
        this.servicioBCCR = new ServicioBCCR(); // INICIALIZACIÓN EN CONSTRUCTOR
    }

    public void atenderTiqueteEnCaja(int numCaja) {

        Caja cajaObjetivo = null;

        // Identificar a qué caja corresponde el número ingresado
        if (cajaPreferencial.getNumeroCaja() == numCaja) {
            cajaObjetivo = cajaPreferencial;
        } else if (cajaRapida.getNumeroCaja() == numCaja) {
            cajaObjetivo = cajaRapida;
        } else {
            // Buscamos la caja común en el Árbol Binario de Búsqueda (BST)
            GestionCajaHibridaEstructura.NodoCaja nodoBST = sistemaCajas.buscarNodoCajaPorID(
                    sistemaCajas.getRaizCajas(), numCaja);

            if (nodoBST != null) {
                cajaObjetivo = nodoBST.getDato();
            }
        }

        // Validación de existencia de la caja
        if (cajaObjetivo == null) {
            JOptionPane.showMessageDialog(null,
                    "La Caja #" + numCaja + " no existe o no está registrada en el sistema.",
                    "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Desencolar cliente (Extraer del frente de la cola de prioridad)
        NodoCliente clienteAtendido = cajaObjetivo.getColaClientes().desencolar();

        if (clienteAtendido == null) {
            JOptionPane.showMessageDialog(null, 
                    "La Caja #" + numCaja + " no tiene clientes en fila.",
                    "Caja Vacía", JOptionPane.WARNING_MESSAGE);
            return;
        }

        // Modificar hora de atención
        Date fechaAtencion = new Date();
        SimpleDateFormat formateador = new SimpleDateFormat("dd/MM/yyyy hh:mm:ss a");
        clienteAtendido.setHoraAtencion(formateador.format(fechaAtencion));

        // Calcular tiempo de espera en fila (Módulo 1.4)
        long tiempoSegundos = (fechaAtencion.getTime() - clienteAtendido.getHoraCreacion().getTime()) / 1000;

        // Consultar recomendaciones dinámicas desde el Grafo de Productos
        String recomendacionesGrafo = grafoProductos.obtenerRecomendaciones(clienteAtendido.getTramite());

        // EJECUCIÓN DEL MÓDULO BCCR (Si el trámite es Cambio de Divisas) <--- AQUÍ QUEDA
        String detalleDivisas = "";
        if ("Cambio de Divisas".equalsIgnoreCase(clienteAtendido.getTramite().trim())) {
            String resumenOperacion = servicioBCCR.procesarCambioDivisas();
            detalleDivisas = "\n\n=== OPERACIÓN CAMBIARIA BCCR ===\n" + resumenOperacion;
        }

        // Notificación emergente al cajero (Atención + Venta Cruzada + Cálculo BCCR)
        String mensajeAtencion = "=== ATENDIENDO CLIENTE ===\n" +
                "• Caja: #" + numCaja + " (" + cajaObjetivo.getTipoCaja() + ")\n" +
                "• Cliente: " + clienteAtendido.getNombre() + "\n" +
                "• Trámite: " + clienteAtendido.getTramite() + "\n" +
                "• Tiempo en espera: " + tiempoSegundos + " segundos\n\n" +
                recomendacionesGrafo +
                detalleDivisas;

        JOptionPane.showMessageDialog(null, mensajeAtencion, "Módulo 1.2 - Atención en Caja", JOptionPane.INFORMATION_MESSAGE);

        // Registrar en el archivo histórico persistente
        guardarEnHistorico(numCaja, clienteAtendido, tiempoSegundos);
    }

    private void guardarEnHistorico(int numCaja, NodoCliente cliente, long tiempo) {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter("historico_reportes.txt", true))) {
            bw.write(numCaja + ";" + cliente.getNombre() + ";" + cliente.getTramite() + ";" + tiempo);
            bw.newLine();
        } catch (IOException e) {
            System.out.println("Error al escribir en el histórico: " + e.getMessage());
        }
    }
}