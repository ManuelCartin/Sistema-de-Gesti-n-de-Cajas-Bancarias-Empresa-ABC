/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.proyectoestructuraempresaabc;
    import java.util.Date;
/**
 *
 * @author user
 */
public class PruebaConcepto {

    public static void compararFechas() {
        // Obtener fecha y hora actual del sistema
        Date fecha1 = new Date();
        
        // Simulación de una fecha futura
        Date fecha2 = new Date(System.currentTimeMillis() + 5000); 
        
        if (fecha2.after(fecha1)) {
            System.out.println("Prueba de Concepto: Fecha 2 es más reciente que Fecha 1");
        }
    }

}
