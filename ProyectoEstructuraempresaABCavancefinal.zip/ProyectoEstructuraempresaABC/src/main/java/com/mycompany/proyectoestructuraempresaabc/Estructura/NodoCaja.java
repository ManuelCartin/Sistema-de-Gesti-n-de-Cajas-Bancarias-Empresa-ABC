/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.proyectoestructuraempresaabc.Estructura;

/**
 *
 * @author user
 */
public class NodoCaja {
    private Caja dato;
    private NodoCaja sig;
    private NodoCaja ant;

    public NodoCaja(Caja dato) {
        this.dato = dato;
        this.sig = null;
        this.ant = null;
    }

    public Caja getDato() { return dato; }
    public NodoCaja getSig() { return sig; }
    public void setSig(NodoCaja sig) { this.sig = sig; }
    public NodoCaja getAnt() { return ant; }
    public void setAnt(NodoCaja ant) { this.ant = ant; }
}