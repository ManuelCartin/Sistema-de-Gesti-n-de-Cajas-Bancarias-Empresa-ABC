/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.proyectoestructuraempresaabc;

import com.mycompany.proyectoestructuraempresaabc.Estructura.Caja;
import com.mycompany.proyectoestructuraempresaabc.Estructura.GestionCajaHibridaEstructura;
import com.mycompany.proyectoestructuraempresaabc.Estructura.GestorReportes;
import com.mycompany.proyectoestructuraempresaabc.Estructura.NodoCliente;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;

/**
 *
 * @author user
 * Credenciales:
 * admin / abc123
 * admin2 / abc456
 */


public class ProyectoEstructuraempresaABC {

    //ESTRUCTURAS GLOBALES
    private static Caja cajaPreferencial;
    private static Caja cajaRapida;
    private static GestionCajaHibridaEstructura sistemaCajas; // Estructura híbrida unificada
    private static ControlAtencion controlAtencion;

    public static void main(String[] args) {
        // Validación/Prueba previa de utilidades
        PruebaConcepto.compararFechas();

        Configuracion config = new Configuracion();

        // MÓDULO 0
        if (!config.cargarConfiguracion()) {
            JOptionPane.showMessageDialog(null, "=== MÓDULO 0: CONFIGURACIÓN INICIAL ===\nNo se detectó el archivo prod.txt.");

            String banco = "";
            while (banco == null || banco.trim().isEmpty()) {
                banco = JOptionPane.showInputDialog(null, "Ingrese el Nombre del Banco:");
                if (banco == null) {
                    JOptionPane.showMessageDialog(null, "La configuración es requerida para iniciar el sistema.", "Cierre", JOptionPane.WARNING_MESSAGE);
                    System.exit(0);
                }
            }

            int cajas = 0;
            // Valida que el usuario ingrese mínimo 4
            while (cajas < 4) {
                try {
                    String inputCajas = JOptionPane.showInputDialog(null, "Cantidad total de cajas (Mínimo 4):");
                    if (inputCajas == null) continue;

                    cajas = Integer.parseInt(inputCajas.trim());

                    if (cajas < 4) {
                        JOptionPane.showMessageDialog(null, "Debe ingresar un mínimo de 4 cajas.", "Validación", JOptionPane.ERROR_MESSAGE);
                    }
                } catch (NumberFormatException e) {
                    JOptionPane.showMessageDialog(null, "Dato inválido. Ingrese un número entero.");
                }
            }
            config.guardarConfiguracion(banco, cajas);
        } else {
            // SEGURIDAD: Si prod.txt tenía menos de 4 cajas guardadas, forzamos el mínimo a 4
            if (config.getCantidadCajas() < 4) {
                config.setCantidadCajas(4);
                config.guardarConfiguracion(config.getNombreBanco(), 4);
                JOptionPane.showMessageDialog(null, "Se ajustó automáticamente la configuración al mínimo requerido de 4 cajas activas.", "Aviso de Sistema", JOptionPane.WARNING_MESSAGE);
            }
        }

        // INICIALIZACIÓN DE LAS ESTRUCTURAS DE DATOS
        cajaPreferencial = new Caja(1, "PREFERENCIAL"); // Caja 1 activa
        cajaRapida = new Caja(2, "RAPIDA");             // Caja 2 activa
        sistemaCajas = new GestionCajaHibridaEstructura();

        // Poblamos la estructura híbrida con las cajas comunes restantes (Mínimo Caja 3 y Caja 4)
        for (int i = 3; i <= config.getCantidadCajas(); i++) {
            sistemaCajas.registrarNuevaCaja(new Caja(i, "COMUN"));
        }

        // Controlador de atención con todas las cajas listas (Integra Grafo + BCCR)
        controlAtencion = new ControlAtencion(sistemaCajas, cajaPreferencial, cajaRapida);

        // LOGIN
        if (!ejecutarLogin()) {
            JOptionPane.showMessageDialog(null, "Cierre de seguridad: Demasiados intentos fallidos o acceso cancelado.", "Acceso Denegado", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // MENÚ PRINCIPAL
        boolean salir = false;
        int comunes = config.getCantidadCajas() - 2;

        String menu = "=== GESTIÓN DE CAJAS - " + config.getNombreBanco().toUpperCase() + " ===\n" +
                      "Distribución establecida (Total: " + config.getCantidadCajas() + " cajas activas):\n" +
                      "• Caja 1: Preferencial\n" +
                      "• Caja 2: Rápida\n" +
                      "• Cajas 3 a " + config.getCantidadCajas() + ": " + comunes + " Cajas Comunes/Múltiples\n\n" +
                      "1. Módulo 1.1 y 1.3: Creación y Enrutamiento de Tiquetes\n" +
                      "2. Mostrar Configuración del Sistema\n" + 
                      "3. Módulo 1.2: Atención de Tiquetes en Caja (Venta Cruzada y BCCR)\n" +
                      "4. Módulo 1.4: Reportes y Estadísticas Históricas\n" +
                      "5. Salir del Sistema";

        while (!salir) {
            String opcion = JOptionPane.showInputDialog(null, menu, "Menú Principal - Sistema Bancario", JOptionPane.PLAIN_MESSAGE);

            if (opcion == null || opcion.equals("5")) {
                salir = true;
                JOptionPane.showMessageDialog(null, "Cerrando la sesión del sistema.", "Salida", JOptionPane.INFORMATION_MESSAGE);
            } else {
                switch (opcion.trim()) {
                    case "1":
                        ejecutarCreacionYEnrutamiento(config);
                        break;
                    case "2": 
                        mostrarConfiguracionActual(config);
                        break;
                    case "3":
                        ejecutarAtencionCaja();
                        break;
                    case "4":
                        GestorReportes.mostrarMenuReportes();
                        break;
                    default:
                        JOptionPane.showMessageDialog(null, "Opción inválida. Seleccione un número de 1 a 5.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        }
    }

    // MÓDULO 1.1/1.3
    private static void ejecutarCreacionYEnrutamiento(Configuracion config) {
        try {
            String nombre = JOptionPane.showInputDialog(null, "Nombre del Cliente:");
            if (nombre == null || nombre.trim().isEmpty()) return;

            String id = JOptionPane.showInputDialog(null, "ID / Cédula del Cliente:");
            if (id == null || id.trim().isEmpty()) return;

            String edadStr = JOptionPane.showInputDialog(null, "Edad del Cliente:");
            if (edadStr == null || edadStr.trim().isEmpty()) return;
            int edad = Integer.parseInt(edadStr.trim());

            // Selección de Trámite
            String[] tramites = {"Depósitos", "Retiros", "Cambio de Divisas"};
            int seleccionTramite = JOptionPane.showOptionDialog(null, "Seleccione el trámite a realizar:", "Trámites",
                    JOptionPane.DEFAULT_OPTION, JOptionPane.QUESTION_MESSAGE, null, tramites, tramites[0]);
            
            if (seleccionTramite == -1) return;
            String tramiteAsignado = tramites[seleccionTramite];

            // Selección de Tipo de Tiquete para prioridad
            String[] tipos = {
                "Preferencial (Embarazo, Discapacidad, Adulto Mayor, Empresarial)",
                "Un solo trámite (No preferencial)",
                "Dos o más trámites (No preferencial)"
            };
            int seleccionTipo = JOptionPane.showOptionDialog(null, "Seleccione su condición de atención:", "Tipo de Cliente",
                    JOptionPane.DEFAULT_OPTION, JOptionPane.QUESTION_MESSAGE, null, tipos, tipos[0]);

            if (seleccionTipo == -1) return;

            char tipoChar;
            int cantidadTramites;
            if (seleccionTipo == 0) {
                tipoChar = 'P';
                cantidadTramites = 1;
            } else if (seleccionTipo == 1) {
                tipoChar = 'A';
                cantidadTramites = 1;
            } else {
                tipoChar = 'B';
                cantidadTramites = 2;
            }

            // MÓDULO 1.3
            String destinoFinal = sistemaCajas.clasificarCliente(tipoChar, cantidadTramites);
            String cajaDestinoTexto = "";
            int personasAdelante = 0;
            int consecutivoActual = 0;

            if (destinoFinal.equals("PREFERENCIAL")) {
                personasAdelante = cajaPreferencial.getColaClientes().insertarTiquete(nombre, id, edad, tramiteAsignado, tipoChar);
                consecutivoActual = cajaPreferencial.getColaClientes().getContadorTiquetes();
                cajaDestinoTexto = "Caja 1 (Preferencial)";
            } 
            else if (destinoFinal.equals("RAPIDA")) {
                personasAdelante = cajaRapida.getColaClientes().insertarTiquete(nombre, id, edad, tramiteAsignado, tipoChar);
                consecutivoActual = cajaRapida.getColaClientes().getContadorTiquetes();
                cajaDestinoTexto = "Caja 2 (Rápida)";
            } 
            else {
                // Balanceo dinámico optimizado con la estructura circular interna
                GestionCajaHibridaEstructura.NodoCaja nodoMasVacio = sistemaCajas.getIni();
                if (nodoMasVacio != null) {
                    Caja cajaMasVacia = nodoMasVacio.getDato();
                    
                    // Extraemos temporalmente de la lista circular para actualizar posiciones de forma segura
                    sistemaCajas.extraerCajaDeLista(cajaMasVacia.getNumeroCaja());
                    
                    personasAdelante = cajaMasVacia.getColaClientes().insertarTiquete(nombre, id, edad, tramiteAsignado, tipoChar);
                    consecutivoActual = cajaMasVacia.getColaClientes().getContadorTiquetes();
                    cajaDestinoTexto = "Caja Múltiple #" + cajaMasVacia.getNumeroCaja();
                    
                    // Reinsertamos utilizando el método propio para que ordene automáticamente
                    sistemaCajas.insertarEnLista(nodoMasVacio);
                } else {
                    JOptionPane.showMessageDialog(null, "Error: No existen cajas convencionales registradas.", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }
            }

            Date fechaActual = new Date(); 
            SimpleDateFormat formateador = new SimpleDateFormat("dd/MM/yyyy hh:mm:ss a");
            String fechaFormateada = formateador.format(fechaActual);

            String tiqueteImpreso = "=== TIQUETE GENERADO ===\n" +
                                    "Fecha Emisión: " + fechaFormateada + "\n" + 
                                    "Cliente: " + nombre + "\n" +
                                    "Número de Tiquete: #" + consecutivoActual + "\n" +
                                    "Tipo de Fila: " + tipoChar + "\n" +
                                    "Trámite: " + tramiteAsignado + "\n" +
                                    "Diríjase a: " + cajaDestinoTexto + "\n";

            if (personasAdelante == 0) {
                tiqueteImpreso += "\n¡Es su turno! Pase a la caja asignada de inmediato.";
            } else {
                tiqueteImpreso += "Personas por delante en la fila: " + personasAdelante;
            }

            JOptionPane.showMessageDialog(null, tiqueteImpreso, "Tiquete Impreso", JOptionPane.INFORMATION_MESSAGE);

        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "La edad ingresada debe ser un valor numérico entero.", "Error de Entrada", JOptionPane.ERROR_MESSAGE);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error al capturar datos del cliente: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    // MÓDULO 1.2 ATENCIÓN DE TIQUETES
    private static void ejecutarAtencionCaja() {
        String inputCaja = JOptionPane.showInputDialog(null, "Ingrese el número de caja que va a atender:");
        if (inputCaja != null && !inputCaja.trim().isEmpty()) {
            try {
                int numCajaAtender = Integer.parseInt(inputCaja.trim());
                controlAtencion.atenderTiqueteEnCaja(numCajaAtender);
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(null, "Número de caja inválido.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    // LOGIN
    private static boolean ejecutarLogin() {
        String usuarioCorrecto = "admin";
        String claveCorrecta = "abc123";
        String usuarioCorrecto2 = "admin2";
        String claveCorrecta2 = "abc456";
        int intentos = 3;

        while (intentos > 0) {
            String user = JOptionPane.showInputDialog(null, "Ingrese el Usuario administrador:", "Login de Seguridad", JOptionPane.QUESTION_MESSAGE);
            if (user == null) return false; 

            JPasswordField campoPassword = new JPasswordField();
            int opcionBoton = JOptionPane.showConfirmDialog(null, campoPassword, "Ingrese la Contraseña:", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
            
            if (opcionBoton != JOptionPane.OK_OPTION) return false; 
            String pass = new String(campoPassword.getPassword());

            // Validación de credenciales para ambos administradores
            if ((user.equals(usuarioCorrecto) && pass.equals(claveCorrecta)) || 
                (user.equals(usuarioCorrecto2) && pass.equals(claveCorrecta2))) {
                JOptionPane.showMessageDialog(null, "¡Acceso Concedido!\nBienvenido al panel del sistema bancario.", "Login Exitoso", JOptionPane.INFORMATION_MESSAGE);
                return true;
            } else {
                intentos--;
                JOptionPane.showMessageDialog(null, "Credenciales incorrectas.\nIntentos restantes: " + intentos, "Error de Autenticación", JOptionPane.WARNING_MESSAGE);
            }
        }
        return false;
    }

    // MOSTRAR CONFIGURACIÓN
    private static void mostrarConfiguracionActual(Configuracion config) {
        String infoConfig = "=== CONFIGURACIÓN ACTUAL DEL SISTEMA ===\n\n" +
                            "• Banco: " + config.getNombreBanco() + "\n" +
                            "• Cajas Registradas: " + config.getCantidadCajas() + " cajas\n" +
                            "• Archivo persistente: prod.txt\n\n" +
                            "Distribución Operativa:\n" +
                            " - 1 Caja Preferencial (Caja #1)\n" +
                            " - 1 Caja Rápida (Caja #2)\n" +
                            " - " + (config.getCantidadCajas() - 2) + " Cajas Convencionales (Cajas #3 a #" + config.getCantidadCajas() + ")";
        
        JOptionPane.showMessageDialog(null, infoConfig, "Información del Sistema", JOptionPane.INFORMATION_MESSAGE);
    }
}