/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.proyectoestructuraempresaabc.Estructura;

/**
 *
 * @author user
 */

public class NodoArista {
    private NodoProducto destino;
    private NodoArista siguiente;

    public NodoArista(NodoProducto destino) {
        this.destino = destino;
        this.siguiente = null;
    }

    public NodoProducto getDestino() {
        return destino;
    }

    public void setDestino(NodoProducto destino) {
        this.destino = destino;
    }

    public NodoArista getSiguiente() {
        return siguiente;
    }

    public void setSiguiente(NodoArista siguiente) {
        this.siguiente = siguiente;
    }
}