/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.proyectoestructuraempresaabc.Estructura;
    import java.util.Date;
/**
 *
 * @author user
 */
public class NodoCliente {
    // Atributos
    private String nombre;
    private String id;
    private int edad;
    private Date horaCreacion;
    private String horaAtencion; 
    private String tramite;     
    private char tipo;           
    private int numeroTiquete;
    private NodoCliente siguiente;

    public NodoCliente(String nombre, String id, int edad, String tramite, char tipo, int numeroTiquete) {
        this.nombre = nombre;
        this.id = id;
        this.edad = edad;
        this.horaCreacion = new Date(); // Obtiene hora del OS
        this.horaAtencion = "-1";
        this.tramite = tramite;
        this.tipo = tipo;
        this.numeroTiquete = numeroTiquete;
        this.siguiente = null;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public Date getHoraCreacion() {
        return horaCreacion;
    }

    public void setHoraCreacion(Date horaCreacion) {
        this.horaCreacion = horaCreacion;
    }

    public String getHoraAtencion() {
        return horaAtencion;
    }

    public void setHoraAtencion(String horaAtencion) {
        this.horaAtencion = horaAtencion;
    }

    public String getTramite() {
        return tramite;
    }

    public void setTramite(String tramite) {
        this.tramite = tramite;
    }

    public char getTipo() {
        return tipo;
    }

    public void setTipo(char tipo) {
        this.tipo = tipo;
    }

    public int getNumeroTiquete() {
        return numeroTiquete;
    }

    public void setNumeroTiquete(int numeroTiquete) {
        this.numeroTiquete = numeroTiquete;
    }

    public NodoCliente getSiguiente() {
        return siguiente;
    }

    public void setSiguiente(NodoCliente siguiente) {
        this.siguiente = siguiente;
    }

    @Override
    public String toString() {
        return "NodoCliente{" + "nombre=" + nombre + ", id=" + id + ", edad=" + edad + ", horaCreacion=" + horaCreacion + ", horaAtencion=" + horaAtencion + ", tramite=" + tramite + ", tipo=" + tipo + ", numeroTiquete=" + numeroTiquete + ", siguiente=" + siguiente + '}';
    }
    
}
