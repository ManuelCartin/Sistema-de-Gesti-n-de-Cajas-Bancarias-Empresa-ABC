/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.proyectoestructuraempresaabc.Estructura;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import javax.swing.JOptionPane;

/**
 *
 * @author user
 * MÓDULO DE REPORTES Y HISTÓRICO
 */

public class GestorReportes {

    private static final String ARCHIVO_HISTORICO = "historico_reportes.txt";

    public static void mostrarMenuReportes() {
        File file = new File(ARCHIVO_HISTORICO);
        if (!file.exists() || file.length() == 0) {
            JOptionPane.showMessageDialog(null, 
                    "No hay registros históricos disponibles aún.\nAtienda al menos un cliente para generar datos.", 
                    "Histórico Vacío", JOptionPane.WARNING_MESSAGE);
            return;
        }

        String menu = "=== MÓDULO DE REPORTES Y ESTADÍSTICAS ===\n" +
                      "1. Resumen General de Atención (Promedios y Totales)\n" +
                      "2. Desglose por Tipo de Trámite\n" +
                      "3. Buscar Atención por Nombre de Cliente\n" +
                      "4. Volver al Menú Principal";

        boolean volver = false;
        while (!volver) {
            String op = JOptionPane.showInputDialog(null, menu, "Reportes del Sistema", JOptionPane.PLAIN_MESSAGE);
            if (op == null || op.equals("4")) {
                volver = true;
            } else {
                switch (op) {
                    case "1":
                        generarReporteGeneral();
                        break;
                    case "2":
                        generarReportePorTramite();
                        break;
                    case "3":
                        buscarAtencionPorCliente();
                        break;
                    default:
                        JOptionPane.showMessageDialog(null, "Opción no válida.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        }
    }

    private static void generarReporteGeneral() {
        int totalClientes = 0;
        long tiempoTotalGeneral = 0;

        // Instancia de la Lista Enlazada propia
        ListaEstadisticasCaja listaEstadisticas = new ListaEstadisticasCaja();

        try (BufferedReader br = new BufferedReader(new FileReader(ARCHIVO_HISTORICO))) {
            String linea;
            while ((linea = br.readLine()) != null) {
                if (linea.trim().isEmpty()) continue;

                // Extracción manual de subcadenas sin usar String.split()
                int numCaja = Integer.parseInt(extraerCampoManual(linea, 0));
                long tiempo = Long.parseLong(extraerCampoManual(linea, 3));

                totalClientes++;
                tiempoTotalGeneral += tiempo;

                listaEstadisticas.acumularAtencion(numCaja, tiempo);
            }

            if (totalClientes == 0) {
                JOptionPane.showMessageDialog(null, "El archivo histórico no contiene registros válidos.");
                return;
            }

            double promedioGeneral = (double) tiempoTotalGeneral / totalClientes;

            // Recorrido de la lista usando los getters de la clase NodoEstadisticaCaja
            NodoEstadisticaCaja aux = listaEstadisticas.getCabeza();
            int cajaMasAtendio = -1;
            int maxAtenciones = -1;
            int cajaMasRapida = -1;
            double menorPromedioTiempo = Double.MAX_VALUE;

            while (aux != null) {
                if (aux.getTotalClientesAtendidos() > maxAtenciones) {
                    maxAtenciones = aux.getTotalClientesAtendidos();
                    cajaMasAtendio = aux.getNumCaja();
                }

                double promedioCaja = aux.getPromedioTiempo();
                if (promedioCaja < menorPromedioTiempo) {
                    menorPromedioTiempo = promedioCaja;
                    cajaMasRapida = aux.getNumCaja();
                }

                aux = aux.getSiguiente();
            }

            String reporte = "=== RESUMEN GENERAL DE ESTADÍSTICAS ===\n\n" +
                             "• Total de clientes atendidos: " + totalClientes + "\n" +
                             "• Tiempo promedio general de espera: " + String.format("%.2f", promedioGeneral) + " segundos\n" +
                             "• Caja con mayor flujo de clientes: Caja #" + cajaMasAtendio + " (" + maxAtenciones + " atendidos)\n" +
                             "• Caja con menor tiempo promedio de espera: Caja #" + cajaMasRapida + " (" + String.format("%.2f", menorPromedioTiempo) + " seg/promedio)";

            JOptionPane.showMessageDialog(null, reporte, "Estadísticas Generales", JOptionPane.INFORMATION_MESSAGE);

        } catch (IOException | NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Error al procesar el histórico: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private static void generarReportePorTramite() {
        int depositos = 0, retiros = 0, divisas = 0;

        try (BufferedReader br = new BufferedReader(new FileReader(ARCHIVO_HISTORICO))) {
            String linea;
            while ((linea = br.readLine()) != null) {
                if (linea.trim().isEmpty()) continue;

                String tramite = extraerCampoManual(linea, 2);

                if ("Depósitos".equalsIgnoreCase(tramite)) depositos++;
                else if ("Retiros".equalsIgnoreCase(tramite)) retiros++;
                else if ("Cambio de Divisas".equalsIgnoreCase(tramite)) divisas++;
            }

            String reporte = "=== DESGLOSE POR TIPO DE TRÁMITE ===\n\n" +
                             "• Depósitos procesados: " + depositos + "\n" +
                             "• Retiros procesados: " + retiros + "\n" +
                             "• Cambio de Divisas procesados: " + divisas + "\n\n" +
                             "Total trámites: " + (depositos + retiros + divisas);

            JOptionPane.showMessageDialog(null, reporte, "Reporte por Trámite", JOptionPane.INFORMATION_MESSAGE);

        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error al leer el histórico: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private static void buscarAtencionPorCliente() {
        String busqueda = JOptionPane.showInputDialog(null, "Ingrese el nombre del cliente a buscar:");
        if (busqueda == null || busqueda.trim().isEmpty()) return;

        StringBuilder resultados = new StringBuilder("=== HISTORIAL ENCONTRADO PARA: " + busqueda + " ===\n\n");
        boolean encontrado = false;

        try (BufferedReader br = new BufferedReader(new FileReader(ARCHIVO_HISTORICO))) {
            String linea;
            while ((linea = br.readLine()) != null) {
                if (linea.trim().isEmpty()) continue;

                String nombre = extraerCampoManual(linea, 1);
                if (nombre.toLowerCase().contains(busqueda.toLowerCase().trim())) {
                    String numCaja = extraerCampoManual(linea, 0);
                    String tramite = extraerCampoManual(linea, 2);
                    String tiempo = extraerCampoManual(linea, 3);

                    resultados.append("• Caja #").append(numCaja)
                              .append(" | Trámite: ").append(tramite)
                              .append(" | Tiempo de espera: ").append(tiempo).append(" seg\n");
                    encontrado = true;
                }
            }

            if (encontrado) {
                JOptionPane.showMessageDialog(null, resultados.toString(), "Coincidencias Encontradas", JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(null, "No se encontraron registros de atención para: " + busqueda, "Sin Resultados", JOptionPane.WARNING_MESSAGE);
            }

        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error al realizar la búsqueda: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private static String extraerCampoManual(String linea, int indiceDeseado) {
        int inicio = 0;
        int contadorDelimitadores = 0;

        for (int i = 0; i < linea.length(); i++) {
            if (linea.charAt(i) == ';') {
                if (contadorDelimitadores == indiceDeseado) {
                    return linea.substring(inicio, i);
                }
                contadorDelimitadores++;
                inicio = i + 1;
            }
        }

        if (contadorDelimitadores == indiceDeseado) {
            return linea.substring(inicio);
        }

        return "";
    }
}